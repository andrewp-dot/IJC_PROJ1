#ifndef ERR_H
#define ERR_H

void warning_msg(const char *fmt, ...);
void error_exit(const char *fmt, ...);


#endif
