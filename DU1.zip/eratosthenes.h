#ifndef ERATOSTHENES_H
#define ERATOSTHENES_H

#include "bitset.h"

void eratosthenes(bitset_t * arr);
void printPrimes(bitset_t * arr);

#endif
