/*
    eratosthenes.c
    IJC-DU1, príklad a), 5.3.2022
    Autor: Adrián Ponechal, FIT
    Přeloženo: Apple clang version 13.0.0 (clang-1300.0.27.3)
    
    Popis: 
        Funkcia eratoshtenes - eratosthenov algoritmus na vyhladavanie prvočísel,
        funkcia preberá ukazateľ na pole typu bitset_t (unsigned long). Každé prvočíslo
        v tomto poli je po vykonaní algortimu označené 0, násobky prvočísel sú nastavené
        na bit s hodnotou 1.

        Funkcia printPrimes - funkcia na vypis prvocisel.
*/

#include <stdio.h>
#include <stdlib.h>

#include <math.h>
#include "bitset.h"

void eratosthenes(bitset_t * arr)
{
    const int arraySize = bitset_size(arr);
    double limit = sqrt(bitset_size(arr));

    for(int idx = 2; idx <= (int)limit; idx++)
    {
        if(bitset_getbit(arr,idx) == 0)
        {
            for(int multiplier = 2; idx*multiplier < arraySize; multiplier++ )
            {
                bitset_setbit(arr,idx*multiplier,1);
            }
        }
    }
}


//vypsat poslednych 10 prvocisel VZOSTUPNE
void printPrimes(bitset_t * arr)
{
    int count = 0;
    for(int idx = bitset_size(arr)-1; idx >= 2; idx--)
    {
        if(bitset_getbit(arr,idx) == 0 )
        {
            printf("%d \n", idx);
            count++;
            if(count == 10)return;
        }
    }
}
